package com.employee;

public class DateofJoin
{
	int day,month,year;

	public DateofJoin(int day, int month, int year) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
	}
	public void showDate()
	{
		System.out.println("Date of Joining:"+day+"-"+month+"-"+year);
	}

}
