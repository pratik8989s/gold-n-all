package com.employee;

import java.util.Scanner;

public class Operational extends Employee
{
	public Operational(int empId, String empName, DateofJoin dateOfJoin,
			double basicSal) {
		super(empId, empName, dateOfJoin, basicSal);

	}

	String jobDesc="Operational";
	String grade="O";
	float salary;
	public void showDetails()
	{
		
		System.out.println("Enter emp ID:"+empId);
		
		System.out.println("Enter emp name:"+empName);
			
		System.out.println("Enter basic salary:"+basicSal);
						
		System.out.println("Job Desc:"+jobDesc);
			
		System.out.println("Grade:"+grade);
		
		System.out.println("Salary of "+empName+" is: "+salary);
	}
	
	public void calcSal()
	{
		
		salary=(float)(basicSal+ (basicSal*0.05));
		
	}
	}
	


