package com.testemp;

import java.util.Scanner;

import com.employee.DateofJoin;
import com.employee.Employee;
import com.employee.Operational;
import com.employee.Technical;

public class TestEmployee
{
	public static void main(String[] args) 
	{
		Employee emp[]=new Employee[2];
		Scanner sc=new Scanner(System.in);
		
		int day,month,year;
		System.out.println("Enter date of joining:");
		day=sc.nextInt();
		month=sc.nextInt();
		year=sc.nextInt();
		
		DateofJoin dateofjoin=new DateofJoin(day,month,year);
		
		int empId=(int)Math.round(Math.random()*10);
		
		System.out.println("Select a option");
		System.out.println("1.Technical employee\n2.Operational employee");
		int x=sc.nextInt();
		
		System.out.println("Enter emp name:");
		String empName=sc.next();
	
		System.out.println("Enter basic salary:");
		double basicSal=sc.nextDouble();
								
		switch(x)
		{
		case 1:
			emp[0]=new Technical(empId, empName, dateofjoin, basicSal);
			dateofjoin.showDate();
			emp[0].calcSal();
			emp[0].showDetails();
			
			break;
						
		case 2:
			emp[1]=new Operational(empId, empName, dateofjoin, basicSal);
			dateofjoin.showDate();
			emp[1].calcSal();
			emp[1].showDetails();
			
			break;
		default:
			System.out.println("Invalid Option");
		}
	}

}
