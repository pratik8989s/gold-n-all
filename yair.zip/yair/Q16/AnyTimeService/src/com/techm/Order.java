package com.techm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Order {

	private int orderId;
	private String orderType;
	private String orderDescription;
	private String orderStatus="None";
	public Order(int orderId, String orderType, String orderDescription) {
		super();
		
		this.orderId = orderId;
		this.orderType = orderType;
		this.orderDescription = orderDescription;
		
	}
		
	public int getOrderId() {
		return orderId;
	}
	public String getOrderType() {
		return orderType;
	}
	public String getOrderDescription() {
		return orderDescription;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		if(orderStatus.equals("Open") || orderStatus.equals("Closed"))
		{
			this.orderStatus=orderStatus;
		}
		else
		{
			try
			{
			throw new InvalidStatusException("status is neither open nor closed.");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
	}	

}