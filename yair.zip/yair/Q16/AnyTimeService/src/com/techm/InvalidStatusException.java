package com.techm;

public class InvalidStatusException extends RuntimeException {
	InvalidStatusException(String desc)
	{
		super(desc);
	}

}
