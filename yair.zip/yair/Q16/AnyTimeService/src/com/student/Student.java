package com.student;

import java.io.Serializable;

public class Student implements Serializable{

	int rollNo;
	String name;
	String major;
	
	
	public int getRollNo() {
		return rollNo;
	}


	public String getName() {
		return name;
	}


	public String getMajor() {
		return major;
	}


	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setMajor(String major) {
		this.major = major;
	}


}
