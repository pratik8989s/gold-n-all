package com.student;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class StoreStudent  {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Student RollNo:");
		int rollNo=Integer.parseInt(br.readLine());
		System.out.println("Enter Student Name:");
		String name=br.readLine();
		System.out.println("Enter Major:");
		String major=br.readLine();
		Student student=new Student();
		student.setRollNo(rollNo);
		student.setName(name);
		student.setMajor(major);
		String fileName=args[0];
		FileOutputStream fos=new FileOutputStream(fileName);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(student);
		FileInputStream fis=new FileInputStream(fileName);
		ObjectInputStream ois=new ObjectInputStream(fis);
		Student std=(Student)ois.readObject();
		System.out.println("RollNo"+"\t"+"Name"+"\t"+"Major");
		System.out.println(std.getRollNo()+"\t"+std.getName()+"\t"+std.getMajor());
		
		

	}

}
