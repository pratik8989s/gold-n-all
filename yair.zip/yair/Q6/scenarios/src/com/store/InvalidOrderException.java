package com.store;


 public class InvalidOrderException extends Exception  {
	
   InvalidOrderException(String s)
  {
	    super(s);
	
  }
	

}
