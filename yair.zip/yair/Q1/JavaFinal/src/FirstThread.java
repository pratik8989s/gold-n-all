import java.util.ArrayList;
import java.util.Scanner;

public class FirstThread extends Thread {

	Item item[] = new Item[5];
	ArrayList al = new ArrayList();
	Scanner sc = new Scanner(System.in);

	public void run() {
		synchronized (this) {
			System.out.println("First thread getting lock to take the Item details\n");
			
			//getting the item details 
			for (int obj = 0; obj < 5; obj++) {
				System.out.println("Enter  Item " + (obj + 1) + " details");
				System.out.println("Enter Itemid");
				int id = sc.nextInt();
				System.out.println("Enter the ItemName");
				String name = sc.next();
				
				//Initializing the item details using constructor
				item[obj] = new Item(id, name);
				
				//Adding the item Objects into an arrayList
				al.add(item[obj]);
			}
			System.out.println("\nFirst thread giving notification to Second thread\n");
			this.notify();
		}
	}
}
