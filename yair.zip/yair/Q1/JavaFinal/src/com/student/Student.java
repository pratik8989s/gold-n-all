package com.student;

import java.io.Serializable;
import java.util.Scanner;

public class Student implements StudentInt,Serializable{
	private int rollNo;
	private String name;
	private int subject1;
	private int subject2;
	private int subject3;
	private int totalMarks;
	@Override
	public void readStudInfo() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student details");
		System.out.println("Enter RoolNo "); this.rollNo=sc.nextInt();
		System.out.println("Enter Name  "); this.name=sc.next();
		System.out.println("Enter Marks  sub1:"); this.subject1=sc.nextInt();
		System.out.println("Enter Marks  sub2:"); this.subject2=sc.nextInt();
		System.out.println("Enter Marks  sub3:"); this.subject3=sc.nextInt();
		
	}
	@Override
	public void calcTotal() {
		this.totalMarks=subject1+subject2+subject3;
	}
	@Override
	public void printStudInfo() {
		System.out.println("roll number of the student is..." +rollNo);
		System.out.println("name of the student is..." + name);
		System.out.println("subject1 marks of student is..." + subject1);
		System.out.println("subject2 marks of the student is..." + subject2);
		System.out.println("subject3 marks of the student is..." + subject3);
		System.out.println("total marks of the student is..." + totalMarks);
		
	}
	
}
