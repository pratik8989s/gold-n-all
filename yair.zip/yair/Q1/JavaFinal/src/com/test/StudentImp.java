package com.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

import com.student.Student;

public class StudentImp {

	

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		System.out.println("Enter no of students");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Student stud_array[]=new Student[n];
		for(int i=0;i<n;i++)
		{
			stud_array[i]=new Student();
			stud_array[i].readStudInfo();
			stud_array[i].calcTotal();
			
		}
	/*	Student s=new Student();
		s.readStudInfo();
		s.calcTotal();*/
		
		
		//Serialization starts

		FileOutputStream fos = new FileOutputStream("StudentInfo.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		for(int i=0;i<n;i++)
		{
			oos.writeObject(stud_array[i]);
		}
		
		//Deserialization starts
		FileInputStream fis = new FileInputStream("StudentInfo.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		for(int i=0;i<n;i++)
		{
				
						Student s1 = (Student) ois.readObject();
						s1.printStudInfo();
		}

		
		
		
	}

}
