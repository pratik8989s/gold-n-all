package com.bankutil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

import com.bank.Account;
import com.bank.Customer;

public class BankUtil {
	static String savAccNo = null;
	static String currAccNo = null;
	static double sBal;
	static double cBal;
	static Customer[] c;
	static Account[] sa;
	static Account[] ca;
	static String savChequeBookStatus;
	static String currChequeBookStatus;
	static int k;
	
	public static void main(String[] args) throws IOException, InterruptedException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no of customers");
		int noOfCust = sc.nextInt();
		c = new Customer[noOfCust];
		sa = new Account[noOfCust];
		ca = new Account[noOfCust];
		for (int i = 0; i < noOfCust; i++) {

			// customer details
			System.out.println("enter customer no:");
			int custNo = sc.nextInt();
			System.out.println("enter customer name");
			String name = sc.next();
			System.out.println("enter customer mobile number");
			int num = sc.nextInt();
			c[i] = new Customer(custNo, name, num);

			// bank account details
			System.out.println("enter which acc to be created from below");
			System.out.println("1.savings account");
			System.out.println("2.current account");
			System.out.println("3.savings and current");
			int choice = sc.nextInt();

			if (choice == 1) {
				System.out.println("enter saving acc no:");
				savAccNo = sc.next();
				System.out.println("enter balance to be credited:");
				sBal = sc.nextInt();
				System.out.println("Do you need chequebook");
				savChequeBookStatus = sc.next();
			} else if (choice == 2) {
				System.out.println("enter current acc no:");
				currAccNo = sc.next();
				System.out.println("enter balance to be credited:");
				cBal = sc.nextInt();
				System.out.println("Do you need chequebook");
				currChequeBookStatus = sc.next();
			} else if (choice == 3) {
				System.out.println("enter saving acc no:");
				savAccNo = sc.next();
				System.out.println("enter current acc no:");
				currAccNo = sc.next();
				System.out.println("enter balance to be credited:");
				sBal = sc.nextInt();
				System.out.println("Do you need chequebook");
				savChequeBookStatus = sc.next();
				System.out.println("enter balance to be credited:");
				cBal = sc.nextInt();
				System.out.println("Do you need chequebook");
				currChequeBookStatus = sc.next();
			}

			
			if (savAccNo != null) {
				sa[i] = new Account(savAccNo, sBal, savChequeBookStatus);
				c[i].addNewAccount(sa[i]);
			}
			if (currAccNo != null) {
				ca[i] = new Account(currAccNo, cBal, currChequeBookStatus);
				c[i].addNewAccount(ca[i]);
			}
		}

		for (int j = 0; j < noOfCust; j++) {
			System.out.println("customer no:" + c[j].getCustNo());
			System.out.println("customer name:" + c[j].getCustName());
			System.out.println("customer mobile:" + c[j].getCustPhone());
				k = j;
				if(sa[k].getAccountNumber()!=null){
				System.out.println("savings acc no:"+sa[k].getAccountNumber());
				System.out.println("AccBalance:"+sa[k].getAccountBalance());
				System.out.println("ChequeBookStatus:"+sa[k].getChequeBookstatus());
				}
				if(ca[k].getAccountNumber()!=null){
					System.out.println("current acc no:"+ca[k].getAccountNumber());
					System.out.println("AccBalance:"+ca[k].getAccountBalance());
					System.out.println("ChequeBookStatus:"+ca[k].getChequeBookstatus());
				}

			

		}
	}
}
