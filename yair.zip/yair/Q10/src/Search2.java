import java.util.ArrayList;
import java.util.ListIterator;

class Search2 extends Thread {
	ArrayList al;
	String cafe2;
	Search2(ArrayList al, String cafe2) {
		this.al = al;
		this.cafe2=cafe2;
	}

	public void run()
	{
		synchronized(this)
		{
		if (al.size()!=0) {	
		ListIterator li= al.listIterator();
		int count=0;
		while(li.hasNext())
		{
			Object obj=li.next();
			CyberCafe c= (CyberCafe)obj;
			if(c.cafeName.equals(cafe2))
			{
						System.out.println("Cafe found:"+"\n"+"the cafe details are"+"\n"+c.cafeName+"\n"+c.address+"\n"+c.membersCount+"\n"+c.ratePerHour);
						count++;
			}
			
		}
		if(count==0){
			System.out.println("Cafe not found");
		}
		}
		}
	}
}