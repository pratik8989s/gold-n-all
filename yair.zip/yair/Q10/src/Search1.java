import java.util.ArrayList;
import java.util.ListIterator;

class Search1 extends Thread {
	ArrayList al;
	String cafe1;
	Search1(ArrayList al, String cafe1) {
		this.al = al;
		this.cafe1=cafe1;
	}

	public void run()
	{
		synchronized(this)
		{
		if (al.size()!=0) {	
		ListIterator li= al.listIterator();
		int count=0;
		while(li.hasNext())
		{
			Object obj=li.next();
			CyberCafe c= (CyberCafe)obj;
			if(c.cafeName.equals(cafe1))
			{
						System.out.println("Cafe found:"+"\n"+"the cafe details are"+"\n"+c.cafeName+"\n"+c.address+"\n"+c.membersCount+"\n"+c.ratePerHour);
						count++;
			}
			
		}
		if(count==0){
			System.out.println("Cafe not found");
			System.out.println("enter name of another cafe to search");
		}
		}
		}
	}
}