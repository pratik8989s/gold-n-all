package com.language;

public interface Language {	//Language interface
	void showMessage();

}
