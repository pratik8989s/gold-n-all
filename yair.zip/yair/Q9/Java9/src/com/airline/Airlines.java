package com.airline;
class InvalidInputException extends RuntimeException{
	InvalidInputException(String s){
		super(s);
	}
}
public abstract class Airlines {
	private String airId;
	private String source;
	private String destination;
	public Airlines(String airId, String source, String destination) {
		super();
		InvalidInputException iie1 = new InvalidInputException("invalid airid");
		InvalidInputException iie2 = new InvalidInputException("source and destination should not match");
		if(airId.charAt(0)=='B'&&airId.charAt(1)=='O'&&airId.charAt(2)=='E'&&airId.charAt(3)=='I'&&airId.charAt(4)=='N'&&airId.charAt(5)=='G'){
		this.airId = airId;
		}
		else{
			throw iie1;
		}
		if(source!=destination){
		this.source = source;
		this.destination = destination;
	}
		else{
			throw iie2;
		}
		}
	public abstract void bookTicket(int noOftickets);
	
	
	
	
	
	
}
