import java.util.ArrayList;


public class Flat 
{
	
	int flatId;				
	 String flatType;			
	  double flatCost;
	public Flat(int flatId) {
		super();
		this.flatId = flatId;
		
	}
	public int getFlatId() {
		return flatId;
	}
	public void setFlatId(int flatId) {
		this.flatId = flatId;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		if(flatType.equals("1BHK")||flatType.equals("2BHK")||flatType.equals("3BHK"))
		{
			this.flatType = flatType;
		}
		else
		{
			try
			{
				throw new InvalidInputException("InvalidInputException");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
		
	}
	public double getFlatCost() {
		return flatCost;
	}
	public void setFlatCost(double flatCost) {
		if(flatCost>=1000000)
		{	
		this.flatCost = flatCost;
		}
		else
		{
			try
			{
				throw new InvalidInputException("InvalidInputException");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}                                

	

}
