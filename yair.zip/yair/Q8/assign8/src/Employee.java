import java.util.ArrayList;
import java.util.Iterator;


public class Employee 
{
	int empId;		
	String empName;	
	ArrayList<Flat> flatsSold = new ArrayList<Flat>();
	
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
		
	}
	
	public double calculateIncentive(Flat f)
	{
		double incentive=0;
		if(f.flatType.equals("1BHK"))
		{
			incentive=f.getFlatCost()*0.04;
			System.out.println("Incentive:"+incentive);
		}
		else if(f.flatType.equals("2BHK"))
		{
			incentive=f.getFlatCost()*0.06;
			System.out.println("Incentive:"+incentive);
		}
		else if(f.flatType.equals("3BHK"))
		{
			incentive=f.getFlatCost()*0.08;
			System.out.println("Incentive:"+incentive);
		}
		return incentive;
	}
		public void addFlat (Flat f ) 
		{
			
			flatsSold.add(f);
		}
		public void generateReport()
		{
			Iterator itr=flatsSold.iterator();
			System.out.println("\nEmployee ID:"+empId+"\tEmployee Name:"+empName);
			System.out.println("\nFlat ID:"+"\t"+"Flat Type:"+"\t"+"Flat Cost:");
			while(itr.hasNext())
			{
				Flat f = (Flat)itr.next();
				
				System.out.println(f.getFlatId()+"\t"+f.getFlatType()+"\t"+f.getFlatCost());
				
			}
		}
	
	
	

}
