import java.util.Scanner;

import com.bill.Customer;
import com.bill.PremiumCustomer;
import com.bill.RegularCustomer;

public class TestClient
{
	public static void main(String args[])
	{
		Customer c[] = new Customer[2]; 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 0 for Regular Customer\n1 for Premium Customer");
		int x = sc.nextInt();
		
		System.out.println("Enter  Customer details");
		int customerId= (int)Math.round(Math.random()*10);
		
		System.out.println("Enter Customer Name");
		String customerName=sc.next();
		
		System.out.println("Enter mobile no:");
		long mobileNo = sc.nextLong();
		
		System.out.println("Enter Bill Number");
		int billNo=sc.nextInt();
		
		System.out.println("Enter number of minutes:");
		 int minutes=sc.nextInt();

		switch(x){
		
			case 0:
				c[0]= new RegularCustomer(customerId, customerName, mobileNo, billNo);
				c[0].calculateBill(minutes);
				System.out.println(c[0]);
				break;
			case 1:
				c[1]= new PremiumCustomer(customerId, customerName, mobileNo, billNo);
				c[1].calculateBill(minutes);
				System.out.println(c[1]);
				break;
			default:
				System.out.println("Invalid Option");
				
		}
	}
}
