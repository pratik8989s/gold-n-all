package com.account;

public class MinBalanceException extends RuntimeException{

	public MinBalanceException() {
		super("Min Balance Exception");
		
	}
	
	

}
